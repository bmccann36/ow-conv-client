
var redis = require('redis');
const bluebird = require('bluebird')
const url = require("url");
bluebird.promisifyAll(redis.RedisClient.prototype);


async function main(args) {
  console.log(args.REDIS_URI)
  const client = redis.createClient(args.REDIS_URI,
    {
      tls: { servername: url.parse(args.REDIS_URI).hostname }
    })
  client.on("error", (err) => { console.log("redis error", console.log(err)) });
  client.on("connect", () => { console.log('connected to db') })
  client.on("end", () => { console.log('ended connection') })
  try {
    await client.setAsync('foo', 'bar')
    const fetch = await client.getAsync('foo')
    console.log(fetch)
    client.quit()
  } catch (err) {
    client.quit()
    console.log('caught error', err)
  }

}

// main({ "REDIS_URI": "rediss://admin:BYYBCEKBECJPAZLG@portal1103-6.bmix-dal-yp-8e6a2b9a-783b-4dab-b86b-db03558d92f5.bmccann36-gmail-com.composedb.com:35226" })


exports.main = main;



